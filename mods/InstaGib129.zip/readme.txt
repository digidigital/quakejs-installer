Title    : InstaGib 1.29h
Filename : Instagib129.zip
Version  : 1.29h
Date     : 08/10/01
Author   : {Stacheldraht} stacheldraht@instagibmod.com
Web Page : http://www.instagibmod.com 

Mod Info
=====================================================================================================================

About
=========
InstaGib is a One-Shot, One-Kill mod, using the RailGun only. All items and power ups except CTF Flags have 
been removed from the maps. 

InstaGib is a Server - Side mod, which means it does not require a client download in order to play Online Multiplayer.
This file is only needed if you are going to Play Single-Player, or host a server. For hosting servers I recommend using
the .DLL version of InstaGib 1.29 for optimal performance.

Installation 
=============
Create a folder in your Quake 3 directory called "Instagib129" (without the quotes), which is most likely 
C:\Program Files\Quake III Arena\ so the new path should look something like C:\Program Files\ Quake III Arena\InstaGib129
Add manually or extract InstaGib129.pk3 and readme.txt to this folder (InstaGib129). To play - run Quake 3, 
then click on the Mods button in the main menu, and select InstaGib 1.29h from the list of mods,
start up a game and your fragging!

If you need help, look at http://www.instagibmod.com/support.php . There are links to an FAQ, Forums, and other
various ways to contact me.

Updates
========
1.29 - Added support for 1.29h PR. Now ONLY the RailGun loads during the loading sequence!
1.27 - *Fixed Bot AI, so that they Navigate around maps better. Support for 1.27 PR.
1.17 - One of the first releases, the rest is history.

Availability
=============
You can download this mod from:
http://www.instagibmod.com
Click on the media->downloads link on the left menu.

Contacts
=========
{Stacheldraht} : 
[E-Mail] stacheldraht@instagibmod.com 
[AIM] Lohner TaOpOcL
[ICQ] 117395020

Special Thanks
===============
**To Malcolm Lim and Steve Conway for writing their Tutorials on InstaGib. (Only bot portions were used.) :
http://www.planetquake.com/code3arena
*To Kriger for being on the InstaGib team and helping me out with lots of stuff :
http://www.fortresscenter.com, http://www.q3modcentral.com

Bugs
=====
None Known...