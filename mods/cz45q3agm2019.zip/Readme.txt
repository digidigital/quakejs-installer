CZ45's gameplay mod pack (2019)
---
A set of gameplay changes, and a heavily modified death/gib mechanic. As always, this mod is created
on vanilla Q3A Point Release v1.32. I don't know if it'll work on any other version.

Also includes my latest HD weapon re-texture work.

---
To install:
Place the "cz45q3agm" folder inside your Quake3Arena folder, besides 'baseq3', NOT inside it.

---
To run:
Either use/run the batch file ("CZ45Q3AGameplayMod.bat")

Or make a new Q3A shortcut and add the following line in the target box;

+set fs_game cz45q3agm +set sv_pure 1 +set com_hunkmegs 512 +set com_zonemegs 256 +set com_soundmegs 96

---
To play:
You can create your game in a typical way. Or for a quicker, recommended alternative:
Simply choose a map. ANY map of any gametype of your choosing.
Don't bother on setting up the bots and the game rules. Just quickly start the game.
Once in the game. Press "I" key.

It'll restart the game on recommended settings (which is free for all, no score and time limit)
and slowly fill the game with random bots for you. Enjoy the mayhem. :)

---
About themepaks folder:
By default, the mod uses the Tron-style death/gib effects. the themepaks folder has seven
other alternate death/gib styles.

"pakcz04coins.pk3" is the ReadyPlayerOne(film) style coins effect.

"pakcz04blood.pk3" is the over-the-top emulation of the CoD4 style blood spurt effects.

"pakcz04emcee.pk3" Quake 3, with a little bit of a certain popular videogame's aestethics.

"pakcz04firefx.pk3" for those who wants an explosive theme.

"pakcz04flowers.pk3" serious sam-inspired hippie aestethic.

"pakcz04frosten.pk3" is the theme of choice for those who want to let it go.

"pakcz04maymays.pk3" absolute cancer.

"pakcz04pyuds.pk3" what? You never played Quake 3?...

"pakcz04plasma.pk3" to turn every gladiatiors into plasma goo.

"pakcz04rainbowedition.pk3" for those who wants a proper broken fighting game feel.

"pakcz04retro.pk3" Quake 3 like it's the 80's!

To use, simply copy a pak file of your choice into the "cz45q3agm" folder, just outside "themepaks" folder.
To revert to the default style. Simply remove the used pak file out. Also note that you should only use
one theme pak at a time. As multiple theme paks would lead to file conflicts.

--
List of my gameplay changes/modifications;
CZ45 2017-2019

Bots:
Bots on lower difficulties have halved damage, horrendous health and speed handicap.
Bots on 'hurt me plenty' have halved damage, handicapped health, and speed.
Bots on 'hardcore' have 50% base health handicap.
Bots on 'nightmare', no handicap.
Default bots are now more aggressive on lower difficulties.

General Gameplay:
Unlimited ammo.
Ammo on hud now hidden.
Ammo pickups are now weapon pickups also. Weapons and ammo pickups default respawn time adjusted to minimize bot camping.
Ammo and weapon pickups now also gives tiny amount of armor and health.
No fall damage(can still be killed through pits and voids).
No self-harm damage(have fun with rocket jumps and plasma rides!).
Weapons have improved hit vfx.
Weapons have recoil.
Zoom view function now (nearly)visually emulates ADS mechanic of modern shooters. It however does not give any actual weapon advantage like decreased MG spread, faster rockets, etc...it still mechanically acts as your typical Q3A zoom in function.
-*
Deaths have extravagant, sprite effects.
Virtually invincible corpse.
Certain deaths and weapons insta-gibs player on death.
Quickly after death, corpse gib itself instead of sinking.
Corpse has custom shader wrap on death.
RL, GL & BFG kills have noticeable knockback effect on death. Shotgun pushes player upward on death.
-*Note:Gib effect reverted to my favorite, Tron-ish style.
Weapon brass are now sprites.
Weapon offset adjusted.
Hit-confirm visual cue via crosshair flash effect.
Kill-confirm via audio cue and opponent name pulse.
Muzzle flash duration, increased a bit to be more visible.
Rewritten death announcements. Simplified.

Weapon Specific:
Shotgun pellet count increased.
BFG acts as little bit improved Plasma Gun. Nerfed to prevent absolute map weapon dominance.
PG firing rate decreased a bit.
Railgun reload rate slightly increased.
Railgun through-hit count raised to eight.
Grenade Launcher fire rate increased.
Grenade projectile life span increased.
Various railgun weapon effects color-locked.
Gauntlet kill give 5-points worth of health. Max up to 150pts.
		-CZ45
---