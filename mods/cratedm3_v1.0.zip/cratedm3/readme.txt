Cratedm3 1.0 by Julian 'Juz' Priestley - juz@juz.org.uk
http://www.juz.org.uk

Older versions of the mod should be deleted (or uninstalled 
if you used the installer) before installing this version 
of the mod. Then unzip the mod into your quake 3 directory,
making sure to keep the directories.
For more information please read the manual contained in
the manual directory.