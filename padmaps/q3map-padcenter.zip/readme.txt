4/28/2000
================================================================
Title                   : PadCenter for Quake III Arena
Filename                : padcenter.pk3
Maps			: padcenter.bsp
Author                  : ENTE (Andreas Endres)
Email Address           : mail@padman.de
home page		:http://www.padman.de/maps.html

			 
Description		:Quake III Arena - dm map

Instructions:
-------------
1 ) Extract padCenter.pk3 into your Quake3/baseq3/ directory
2 ) Start Quake3
3 ) Both maps will be accessable from the menu

* Play Information *

type of game:
padCenter - ffa & team dm



 Settings                : Deathmatch, Team Deathmatch
 Bot Support             : Bots are fully supported

			: 
Level Name(s)           : PadCenter
Single Player           : bots
Cooperative 2-4 Player  : bots
Deathmatch Player       : yes
Ctf			: no
Difficulty Settings     : bots again


Puter:			:PII 266mhz /128ram /win95
compile time:		:6 hours with bsp_FullVis extra light..


================================================================
Credits:   
ID Software, for Doom, Quake, Quake II, and Quake3Arena
id software rules !
================================================================

This is  my fourth Map , i hope you have my other maps PADMAN'S PADCASTLE, PADMAN'S PADHOME and PADGALLERY..:-))

A Special Thank to Michel who help me with many tips for my  maps....!!!

http://www.dangerzone.de.st (very good german tutor on his site)


And a very special big Thank to the Quake3 Sites; 

www.quake3world.com  
www.quake.de        
www.planetquake.de
www.planetquake.com
www.k-quake.de
www.qscene.de
www.quakerszone.de
www.q3a.de
www.3d-zone.de
www.quake2.net
www.stomped.com

and to all the other Site for the nice reports of my Maps !
================================================================


* Legal Stuff *

This level is (c) 2000 ENTE (Andreas Endres).
You are not to include or distribute this map in any sort of commercial product without 
first obtaining permission from the author.  You may not mass distribute this level via any 
non-electronic means, including but not limited to compact disks, and floppy disks.

All rights by the artists  !!!!
The Comic charaktere PADMAN (c)ENTE  (duck)




sorry, for my bad english..!!
