2/18/2000
================================================================
Title                   : PADMANS PADCASTLE for Quake III Arena
Filename                : padcastle.pk3
Maps			: padcastle.bsp
Author                  : ENTE (Andreas Endres)
Email Address           : mail@enteswelt.de
home page		:http://www.enteswelt.de

			 
Description		:Quake III Arena - dm map

Instructions:
-------------
1 ) Extract padcastle.pk3 into your Quake3/baseq3/ directory
2 ) Start Quake3
3 ) Both maps will be accessable from the menu

* Play Information *

type of game:
padcastle - ffa & team dm



 Settings                : Deathmatch, Team Deathmatch
 Bot Support             : Bots are fully supported

			: 
Level Name(s)           : padcastle
Single Player           : bots
Cooperative 2-4 Player  : bots
Deathmatch Player       : yes
Ctf			: no
Difficulty Settings     : bots again


Puter:			:PII 266mhz /128ram /win95
compile time:		:26 hours with bsp_FullVis extra light..:-((


================================================================
Credits:   
ID Software, for Doom, Quake, Quake II, and Quake3Arena
id software rules !
================================================================

A Special Thank to Michel who help me with many tips for my first map....!!!

http://www.dangerzone.de.st

================================================================
Also a big thank to all PADMAN fans, the map it's for you...;-))
================================================================


* Legal Stuff *

This level is (c) 2000 ENTE (Andreas Endres).
You are not to include or distribute this map in any sort of commercial product without 
first obtaining permission from the author.  You may not mass distribute this level via any 
non-electronic means, including but not limited to compact disks, and floppy disks.


PADMAN (c)ENTE



sorry, for my bad english..;-))
