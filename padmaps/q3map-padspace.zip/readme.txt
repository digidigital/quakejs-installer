7/29/2000
================================================================
Title                   : PadSpace for Quake III Arena
Filename                : padspace.pk3
Maps			: padspace.bsp
Author                  : ENTE (Andreas Endres)
Email Address           : mail@padman.de
home page		:http://www.padman.de/maps.html

			 
Description		:Quake III Arena - dm map

Instructions:
-------------
1 ) Extract padspace.pk3 into your Quake3/baseq3/ directory
2 ) Start Quake3
3 ) Both maps will be accessable from the menu

* Play Information *

type of game:
padCenter - ffa & team dm



 Settings                : Deathmatch, Team Deathmatch
 Bot Support             : Bots are fully supported

			: 
Level Name(s)           : PadSpace
Single Player           : bots
Cooperative 2-4 Player  : bots
Deathmatch Player       : yes
Ctf			: no
Difficulty Settings     : bots again


Puter:			:PII 266mhz /128ram /win95
compile time:		:7 hours with bsp_FullVis 


================================================================
Credits:   
ID Software, for Doom, Quake, Quake II, and Quake3Arena
id software rules !
================================================================

This is my smal technic design map with many details and many nice light effects.
For this map specialy the swedish band DiESELKOPF write an song, great thanks guys !!!!

DiESELKOPF: 
The man:   Ronny Rassmuson
eMail:     ronny@sjostroms.se
homepage:  http://www.geocities.com/SunsetStrip/Alley/7013/

In this map you will find great textures from Todd 'Mr.CleaN' Rose (http://www.planetquake.com/mrclean/), very good job Todd..!!
Please see the 'mrcleantex_1.txt' readme file !!

I hope you know my other maps PADMAN'S PADCASTLE, PADMAN'S PADHOME, PADGALLERY, PADCENTER, PADGARDEN and PADPOOL..:-))



A Special Thank to Michel who help me with many tips for my  maps....!!!

http://www.dangerzone.de.st (very good german tutor on his site)

And to the Beta tester of PadSpace:

Wrinkle
Mr.Slomo
Angstroem
Karmu
Bonebreaker
Killer_Blanks
3nzo+Forlani
Mephisto
....



And a very special big Thank to the Quake3 Sites; 

www.quake.de        
www.planetquake.de
www.planetquake.com
www.quake3world.com
www.k-quake.de
www.qscene.de
www.quakerszone.de
www.q3a.de
www.3d-zone.de
www.quake2.net
www.stomped.com
www.q3e.yashuu.de/
www.quake3fans.de/
www.planetquake.com/lvl/default.asp


and to all the other Site for the nice reports of my Maps !
================================================================


* Legal Stuff *

This level is (c) 2000 ENTE (Andreas Endres).
You are not to include or distribute this map in any sort of commercial product without 
first obtaining permission from the author.  You may not mass distribute this level via any 
non-electronic means, including but not limited to compact disks, and floppy disks.


The Comic charaktere PADMAN (c)ENTE  (duck)




sorry, for my bad english..!!
