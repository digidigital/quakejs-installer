1/1/2001
================================================================


Title                   : PadGarden for Quake3
Filename                : padgarden.pk3
Maps			: padgarden.bsp
Author                  : ENTE (Andreas Endres)
Email Address           : mail@padman.de
home page		:http://www.padman.de or www.padmaps.de

			 
Description		:Q3A - dm map

Instructions:
-------------
1 ) Extract padgarden.pk3 into your quake3/baseq3/ directory
2 ) Start Quake3
3 ) Both maps will be accessable from the menu

* Playing Information *

type of game:
padgallery - ffa & team dm



 Settings                : Deathmatch, Team Deathmatch
 Bot Support             : Bots are fully supported

			: 
Level Name(s)           : PadGarden
Single Player           : bots
Cooperative 2-4 Player  : bots
Deathmatch Player       : yes
Ctf			: no
Difficulty Settings     : bots again


Puter:			:AMD 900MHz, 256ram, GeFoce2 
compile time:		:3,10 Hours with FullVis 


================================================================

PadGarden was my first liliput Pad-Map for Q3A, in this you are not bigger as an grashopper.
Some time ago I made a new PadGarden version for the Game 'Elite Force' and many Q3 gamers see the pics of my new version, so
they ask me that I can make the new version of PadGarden for Q3A too.
Okay, here is the new version with many new textures, soundfiles and ways.
The new version is a littler bit smaller, because I need a little bit more speed in the map, how in PadKitchen.

PadGarden is one of my popularest Pad-Map ever and you will find many food for your eyes and ears, 
with many fantastic soundfiles and nice jokes..:)

I hope you like it...!!??





================================================================
More of the Pad-Maps you can see on www.padmaps.de..!
See the other 3A Pad-Maps: PADMAN'S PADCASTLE, PADMAN'S PADHOME, PADGALLERY, PADCENTER, 
PADGARDEN, PADPOOL, PadSpace, PadKitchen
Or my EF Pad-Maps; PadGallery, PadKitchen and PadGarden...!
and the only real PADMAN Model from TONE (http://homepages.tig.com.au/~adbell/).
================================================================

The Skybox in PadGarden is from the Mighty Pete
http://www.geocities.com/petes-oasis/ and it was rally perfect for my PadGarden..:)
Big Thanks..!!

Two of the plants shaders are from the great Lloyd Morris, I love his works..Thanks..!

A Special Thank to:

-All the PADMAN and Pad-Maps Fans, you are the best..!!!

-Michel who help me with many tips for my  maps and for the nice skybox....!!!
 http://www.dangerzone.de.st (very good german tutor on his site)


And a very special big Thank to all of the Quake3 Sites; 

www.quake.de        
www.planetquake.de
www.planetquake.com
www.quake3world.com
www.k-quake.de
www.qscene.de
www.quakerszone.de
www.quakequakequake.com
www.fragazone.com
www.extreme-players.de
www.swissarena.ch
www.q3a.de
www.3d-zone.de
www.quake2.net
www.stomped.com
www.q3e.yashuu.de/
www.quake3fans.de/
www.planetquake.com/lvl/default.asp


and to all the other Site for the nice reports of my Maps !
================================================================


* Legal Stuff *

This level is (c) 2000 ENTE (Andreas Endres).
You are not to include or distribute this map in any sort of commercial product without 
first obtaining permission from the author.  You may not mass distribute this level via any 
non-electronic means, including but not limited to compact disks, and floppy disks.


The Comic charaktere PADMAN (c)ENTE  



sorry, for my bad english..!!
