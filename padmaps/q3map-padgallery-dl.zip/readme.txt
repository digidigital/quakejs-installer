6/23/2001
================================================================

DeLuxe Version of ENTE's PadGallery



Title                   : PadGallery DeLuxe
Filename                : padgallery_dl.pk3
Maps			: padgallery_dl.bsp
Author                  : ENTE (Andreas Endres)
Email Address           : mail@padman.de
home page		: http://www.padcity.com or www.padworld.de

PADMAN Statue and the
original PADMAN Model   
by TONE                 : http://www.padcity.com/tone/ 
                          old adress: http://homepages.tig.com.au/~adbell/index.html
                          abell@iname.com   
                          mailto: adbell@ihug.com.au

Music by DiESELKOPF     : http://www.geocities.com/SunsetStrip/Alley/7013/
                          deady@geocities.com    
                          mailto: ronny@sjostroms.se

Plant models by
       Todd Gantzler    : http://i.am/professorQ3  
                          mailto: toddg@slip.net

Skybox by Mighty Pete   : http://www.geocities.com/Paris/LeftBank/8119/
                          mailto: petes-oasis@bigfoot.com

Red images by Redlemons : http://www.planetquake.com/redlemons/
                          mailto: redlemons@planetquake.com

Texures:                : I use many different textures which I collect
			  everywhere, some from graphic programs, some from
			  other maps or even from other games.
			  I don't know where I got some of the textures and I
			  can't thank these person with their names in the
			  credits, I'm sorry. If someone recognizes his texture,
			  please mail me if you don't want your textures to be
			  used.
			  A big thank you to all the authors.

			  In the case of PadGallery DeLuxe I have to thank:
			  -'KINGPIN: LIFE OF CRIME' BY XATRIX ENTERTAINMENT, INC.
			  -'VOYAGER ELITE FORCE' by Raven/Activision
			  because I used many cool textures made by them, thanks a lot!!!
			 
Description		:Q3A - dm map

Instructions:
-------------
1 ) Extract padgallery_dl.pk3 into your quake3/baseq3/ directory
2 ) Start Quake3
3 ) Both maps will be accessable from the menu

* Playing Information *

type of game:
padshop - ffa & team dm



 Settings                : Deathmatch, Team Deathmatch
 Bot Support             : Bots are fully supported

			: 
Level Name(s)           : PadGallery_dl
Single Player           : bots
Cooperative 2-4 Player  : bots
Deathmatch Player       : yes
Ctf			: no
Difficulty Settings     : bots again


Puter:			:AMD 900MHz, 256ram, GeFoce2 
compile time:		:2 Hours with FullVis 


================================================================

PadGallery deLuxe is an overworked version of the old PadGallery and represents a little picture gallery.
The new version is very different to the old one, it is bigger, more colorful, more detailed and simply better..*gg*
You can find many skin motives in the PadGallery deLuxe which is because of the first PadSkin Contest, which had a big influence on the PadMap.
The winner got a complete room for his work, his skin on the statue and publiaction on the american PC Gamer.
Ok, have fun with the new map, I hope you like it..!!?

Ente

================================================================
More of the Pad-Maps you can see on www.padcity.com ..!
See the other Q3A PadMaps: PADMAN'S PADCASTLE, PADMAN'S PADHOME, PADGALLERY, PADCENTER, 
PADGARDEN, PADPOOL, PadSpace, PadKitchen, PadShop
Or my EF PadMaps; PadGallery, PadCenter, PadKitchen and PadGarden...!
and the only real PADMAN Model from TONE (http://homepages.tig.com.au/~adbell/).
================================================================





A Special Thank to:

-All the PadSkin Contest Jury Members:
 In alphabetical order:

 Bomerlunder from bomerlunder.de 
 CaliGirl from gamespy.com
 Forlani from Planetquake.de 
 Harmonieman from Extreme-Players.de 
 JB from RTD Quake III 
 kirin from saphiria.net 
 krow from Skindom.com 
 Pappy-R from Planetquake.com 
 Paul Jaquays from id Software 
 RastaMan from Planetquake.de 
 TONE, maker of the PADMAN model. 
 wolle from quake.de 


-Jeremy Williams:
 for the publishment of the PadGallery deLuxe on the PC Gamer Cover CD and the nice help with the first PadSkinContest.

-TONE:
 the maker of the PADMAN model, I love him for doing this...:)
 He made the cool PadStatue in PadGallery deLuxe. Very nice teamwork again and I hope it was not the
 last.
 
-Ronny:
 the man behind the swedish band DiESELKOPF. Fantastic guy, fantastic music...hear his work in
 PadSpace, PadKitchen and PadShop too.

-the BETA testers of PadGallery deLuxe:

-Bomerlunder   : www.bomerlunder.de
-KARMU         : find him on the PadServer..:)
-Sixpack       : http://www.nahkampfnager.de/
-TimeTurn      : http://www.timeturn.purespace.de/
-frank(ger)    : http://members.tripod.de/frank58739/


-The [PAD]Community and all the PADMAN and PadMaps Fans, you are the best..!!!


-Michel who helped me with many hints for my maps....!!!
 http://www.dangerzone.de.st 


And a very special big Thank to all of the Quake3 Sites; 

www.quake.de        
www.planetquake.de
www.planetquake.com
www.quake3world.com
www.k-quake.de
www.qscene.de
www.quakerszone.de
www.quakequakequake.com
www.fragazone.com
www.extreme-players.de
www.swissarena.ch
www.q3a.de
www.3d-zone.de
www.quake2.net
www.stomped.com
www.q3e.yashuu.de/
www.quake3fans.de/
www.planetquake.com/lvl/default.asp


and to all the other Site for the nice reports of my Maps !
================================================================


* Legal Stuff *

This level is (c) 2001 ENTE (Andreas Endres).
You are not to include or distribute this map in any sort of commercial product without 
first obtaining permission from the author.  You may not mass distribute this level via any 
non-electronic means, including but not limited to compact disks, and floppy disks.

All rights of textures, soundfiles or images are by the Authors.

The Comic charaktere PADMAN (c)ENTE  




sorry, for my bad english..!!
